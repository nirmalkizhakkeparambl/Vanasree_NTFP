package com.gisfy.ntfp.Utils;

public interface Constants {
    String COLLECTORS="Collectors";
    String RFO="RFO";
    String VSS="VSS";

    String ENGLISH="en";
    String MALAYALAM="ml";

    String MAKE_PAYMENTS="Make Payments";
    String RECEIVED_PAYMENTS="Received Payments";
    String STATUS="[{\"Status\":\"Failed To Load\"}]";
}
